## This is a demo "MERN" project
![ajex13](https://img.shields.io/badge/ajex13-this%20react%20project%20rocks-green?style=for-the-badge&logo=React)




     _____ _                 _        _            _         _ _     _   
    /  ___(_)               | |      | |          | |       | (_)   | |  
    \ `--. _ _ __ ___  _ __ | | ___  | |_ ___   __| | ___   | |_ ___| |_ 
     `--. \ | '_ ` _ \| '_ \| |/ _ \ | __/ _ \ / _` |/ _ \  | | / __| __|
    /\__/ / | | | | | | |_) | |  __/ | || (_) | (_| | (_) | | | \__ \ |_ 
    \____/|_|_| |_| |_| .__/|_|\___|  \__\___/ \__,_|\___/  |_|_|___/\__|
                      | |                                                
                      |_|                                                
                      
                      
 ## DEV env steps 
 
 `npm install`
 
 `npm start`

Start the mongodb server using this command: `mongod`


Start the Node.js server using this command: `nodemon server/server`

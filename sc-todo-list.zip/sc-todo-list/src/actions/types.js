// Add task
export const ADD_TASK = 'ADD_TASK';
// Fetch tasks
export const FETCH_TASK = 'FETCH_TASK';
export const FETCH_TASK_SUCCESS = 'FETCH_TASK_SUCCESS';
export const FETCH_TASK_FAIL = 'FETCH_TASK_FAIL';
// Complete task
export const COMPLETE_TASK = 'COMPLETE_TASK';
// Delete task
export const DELETE_TASK = 'DELETE_TASK';
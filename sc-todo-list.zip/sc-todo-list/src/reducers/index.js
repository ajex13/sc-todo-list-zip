import { combineReducers } from 'redux';
import tasks from './taskReducer';
export default combineReducers({
    tasks : tasks
});